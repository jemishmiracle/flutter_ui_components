package com.example.flutter_ui_components

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
