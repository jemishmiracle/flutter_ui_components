import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_material_search_bar/flutter_material_search_bar.dart';

class MaterialSearchBarPage extends StatefulWidget {
  String title;
  MaterialSearchBarPage({super.key,this.title = 'Search Gallery'});
  @override
  State<MaterialSearchBarPage> createState() => _MaterialSearchBarPageState();
}

class _MaterialSearchBarPageState extends State<MaterialSearchBarPage> {
  Icon actionIcon = Icon(Icons.search,color: Colors.white,);
  final MaterialSearchBarController controller = MaterialSearchBarController();
  final TextEditingController editingController = TextEditingController();
  bool onClick =false; bool searchLists = false;
  String searchText = "";
  String previousText1 = "9";
  String previousText2 = "54";
  String nextText1 = "11";
  String nextText2 = "56";
  String hintTexts = 'Search';

  String micText =
      '           "TODO: implement voice input"'"\n"
      "is not a valid integer between 0 and 100,000.""\n"
      "                               Try again.";
  List<searchAppbarData> searchList = [
    searchAppbarData(icon: Icons.history, title: 10),
    searchAppbarData(icon: Icons.history, title: 55),
  ];

  @override
  Widget build(BuildContext context) {
    String titleText =
        "                Press the 🔍	icon in the AppBar""\n"
        "and search for an integer between 0 and 100,000.""\n""\n""\n""\n"
        "                     Last selected integer: ${searchText} .";

    return WillPopScope(
      onWillPop: () {if(controller.isSearchBarVisible){controller.toggleSearchBar();return Future.value(false);} else{return Future.value(true);}},
      child: Scaffold(
        appBar: MaterialSearchBar(
          controller: controller,
          appBar: AppBar(
            backgroundColor: Theme.of(context).secondaryHeaderColor,
            leading: Icon(Icons.menu,color: Theme.of(context).primaryColorDark,),
            title: Text(widget.title,style: TextStyle(color: Theme.of(context).primaryColorDark,fontSize: 14.sp,fontWeight: FontWeight.w600),),
            actions: [IconButton(onPressed: () {controller.toggleSearchBar();setState(() {searchLists = !searchLists;});}, icon: actionIcon),],
          ),
          textField: TextField(
            onChanged: (value) {setState(() {});},
            controller: editingController,
            cursorColor: Theme.of(context).secondaryHeaderColor,
            style: TextStyle(color: Theme.of(context).bottomAppBarColor),
            decoration: InputDecoration(
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              hintText:searchText.isEmpty ? hintTexts : searchText, hintStyle: TextStyle(color: Theme.of(context).focusColor)
            ),
          ),
          color: Theme.of(context).primaryColorDark,
          backButton: IconButton(icon: Icon(Icons.arrow_back,color: Theme.of(context).hoverColor,),
            onPressed: () async {
            controller.toggleSearchBar();setState(() {searchLists = false;});},),
          clearButton: IconButton(icon: Icon(Icons.close,color: Theme.of(context).hoverColor,),
            onPressed: () async {
            controller.toggleSearchBar();
            setState(() {searchLists = false;});},),
        ),
        body: SafeArea(child:
         searchLists ? Container(
           child:searchText.isEmpty ?
              ListView.builder(
               itemCount: searchList.length,
               itemBuilder: (context, index) =>
                    ListTile(
                    onTap: () {
                      setState(() {searchText = searchList[index].title.toString();});},
                    title: Text(searchList[index].title.toString(),),
                    leading: Icon(searchList[index].icon,color: Theme.of(context).hoverColor,size: 5.w,),
                  )
                )
               : searchText == "10" ?
                 valueShow(context: context,number: searchText,num1: nextText1,num2: previousText1)
               : valueShow(context: context,number: searchText,num1: nextText2,num2: previousText2)
           )
             :  Container(
                 child: Center(
                   child:Text(titleText,style: TextStyle(color: Theme.of(context).bottomAppBarColor,fontSize: 10.sp,),),),)
        ),
      ),
    );
  }

  Widget searchData({
    required BuildContext context,
    required String text,Color? textColor}){
    return Container(
      child: Center(
        child:Text(text,style: TextStyle(color: textColor,fontSize: 10.sp),),
      ),
    );
  }

  Widget valueShow({
    required BuildContext context,String? number,
    String? num1,String? num2}){
    return Padding(padding: EdgeInsets.all(1.w),
      child: Column(
        children: [
          Container(
            height: 16.h,width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColorDark,borderRadius: BorderRadius.circular(1.w),
                boxShadow: [BoxShadow(color: Theme.of(context).hoverColor,blurRadius: 3.0,blurStyle: BlurStyle.outer)]
            ),
            child: Column(
              children: [
                Text("This integer",style: TextStyle(fontWeight: FontWeight.normal),),
                SizedBox(height: 2.h,), Text(number ?? "",style: TextStyle(fontSize: 40.sp,fontWeight: FontWeight.normal),),
              ],
            ),
          ),
          SizedBox(height: 1.w,),
          Container(
            height: 16.h,width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColorDark,borderRadius: BorderRadius.circular(1.w),
                boxShadow: [BoxShadow(color: Theme.of(context).hoverColor,blurRadius: 3.0,blurStyle: BlurStyle.outer)]
            ),
            child: Column(
              children: [
                Text("Next integer",style: TextStyle(fontWeight: FontWeight.normal),),
                SizedBox(height: 2.h,), Text(num1 ?? "",style: TextStyle(fontSize: 40.sp,fontWeight: FontWeight.normal),),
              ],
            ),
          ),
          SizedBox(height: 1.w,),
          Container(
            height: 16.h,width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColorDark,borderRadius: BorderRadius.circular(1.w),
                boxShadow: [BoxShadow(color: Theme.of(context).hoverColor,blurRadius: 3.0,blurStyle: BlurStyle.outer)]
            ),
            child: Column(
              children: [
                Text("Previous integer",style: TextStyle(fontWeight: FontWeight.normal),),
                SizedBox(height: 2.h,), Text(num2 ?? "",style: TextStyle(fontSize: 40.sp,fontWeight: FontWeight.normal),),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class searchAppbarData {
  IconData icon;
  int title;

  searchAppbarData({
    required this.icon,
    required this.title,
  });
}
